class Cancion {
  constructor(titulo, duracion, rating, albumID, escuchado) {
    this.titulo = titulo;
    this.duracion = duracion;
    this.rating = rating;
    this.albumID = albumID;
    this.escuchado = escuchado;
  }
}

module.exports = Cancion;
