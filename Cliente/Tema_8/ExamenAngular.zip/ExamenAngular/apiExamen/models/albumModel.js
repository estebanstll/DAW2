class Album {
  constructor(titulo, artista, anio, genero, img) {
    this.titulo = titulo;
    this.artista = artista;
    this.anio = anio;
    this.genero = genero;
    this.img = img;
  }
}

module.exports = Album;
