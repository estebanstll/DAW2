<?php
namespace App\Apirest\Models;

use Tools\Conexion;

class ApiAnimales{

    // GET ALL - Obtener todas las mascotas
    public static function getAll():array{
        $bd = Conexion::getConexion();
        $consulta = "SELECT * FROM mascotas";
        $stmt = $bd->prepare($consulta);
        $stmt->execute();
        $row = $stmt->fetchAll();
        return $row ?: [];
    }

    // GET BY ID - Obtener mascota por ID
    public static function getPorId($id):?array{
        $bd = Conexion::getConexion();
        $consulta = "SELECT * FROM mascotas WHERE id=:id";
        $stmt = $bd->prepare($consulta);
        $stmt->bindParam(":id", $id, \PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetchAll();
        return !empty($row) ? $row[0] : null;
    }

    // POST - Crear nueva mascota
    public static function crear(string $nombre, string $tipo, string $fecha_nacimiento, string $foto_url, int $id_persona):array{
        $bd = Conexion::getConexion();
        $consulta = "INSERT INTO mascotas (nombre, tipo, fecha_nacimiento, foto_url, id_persona) 
                     VALUES (:nombre, :tipo, :fecha_nacimiento, :foto_url, :id_persona)";
        $stmt = $bd->prepare($consulta);
        $stmt->bindParam(":nombre", $nombre);
        $stmt->bindParam(":tipo", $tipo);
        $stmt->bindParam(":fecha_nacimiento", $fecha_nacimiento);
        $stmt->bindParam(":foto_url", $foto_url);
        $stmt->bindParam(":id_persona", $id_persona, \PDO::PARAM_INT);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Mascota creada correctamente', 'id' => $bd->lastInsertId()];
        } else {
            return ['success' => false, 'message' => 'Error al crear la mascota'];
        }
    }

    // UPDATE - Actualizar mascota por ID
    public static function updatePorId($id, string $nombre, string $tipo, string $fecha_nacimiento, string $foto_url, int $id_persona):array{
        $bd = Conexion::getConexion();
        $consulta = "UPDATE mascotas SET nombre=:nombre, tipo=:tipo, fecha_nacimiento=:fecha_nacimiento, foto_url=:foto_url, id_persona=:id_persona WHERE id=:id";
        $stmt = $bd->prepare($consulta);
        $stmt->bindParam(":id", $id, \PDO::PARAM_INT);
        $stmt->bindParam(":nombre", $nombre);
        $stmt->bindParam(":tipo", $tipo);
        $stmt->bindParam(":fecha_nacimiento", $fecha_nacimiento);
        $stmt->bindParam(":foto_url", $foto_url);
        $stmt->bindParam(":id_persona", $id_persona, \PDO::PARAM_INT);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Mascota actualizada correctamente'];
        } else {
            return ['success' => false, 'message' => 'Error al actualizar la mascota'];
        }
    }

    // DELETE - Eliminar mascota por ID
    public static function deletePorId($id):array{
        $bd = Conexion::getConexion();
        $consulta = "DELETE FROM mascotas WHERE id=:id";
        $stmt = $bd->prepare($consulta);
        $stmt->bindParam(":id", $id, \PDO::PARAM_INT);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Mascota eliminada correctamente'];
        } else {
            return ['success' => false, 'message' => 'Error al eliminar la mascota'];
        }
    }

}