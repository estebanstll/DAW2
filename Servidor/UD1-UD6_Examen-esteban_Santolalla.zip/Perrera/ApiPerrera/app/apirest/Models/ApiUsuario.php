<?php
namespace App\Apirest\Models;

use Tools\Conexion;

class ApiUsuario
{
    public static function validarCredenciales(string $email, string $clave)
    {
        $bd = Conexion::getConexion();
        $consulta = "SELECT * FROM veterinarios WHERE email = :email";
        $stmt = $bd->prepare($consulta);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $row = $stmt->fetch();

        if (!$row || $row['clave'] !== $clave) {
            return false;
        }
        return $row;
    }

    public static function registrarUsuario(string $nombre, string $email, string $clave)
    {
        $bd = Conexion::getConexion();
        
        // Verificar si el usuario ya existe
        $consulta = "SELECT * FROM veterinarios WHERE email = :email";
        $stmt = $bd->prepare($consulta);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        
        if ($stmt->fetch()) {
            return ['success' => false, 'message' => 'El usuario ya existe'];
        }
        
        // Insertar el nuevo usuario
        $consulta = "INSERT INTO veterinarios (nombre, email, clave) VALUES (:nombre, :email, :clave)";
        $stmt = $bd->prepare($consulta);
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':clave', $clave);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Usuario creado correctamente', 'id' => $bd->lastInsertId()];
        } else {
            return ['success' => false, 'message' => 'Error al crear el usuario'];
        }
    }

    public static function getAll()
    {
        $bd = Conexion::getConexion();
        $consulta = "SELECT id, nombre, email FROM personas";
        $stmt = $bd->prepare($consulta);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
