<?php
namespace App\Controllers;

use Core\Controller;
use App\Apirest\Models\ApiUsuario;
use App\Apirest\Models\ApiAnimales;
use App\Apirest\Tools\Jwt;

class ApirestController extends Controller
{
    
    public function api(...$params)
    {
        header('Content-Type: application/json; charset=utf-8');

        $recurso = $params[0] ?? null;
        $id = $params[1] ?? null;
        $method = $_SERVER['REQUEST_METHOD'];

        try {
            switch ($recurso) {
                case 'login':
                    if ($method === 'POST') {
                        $this->handleLogin();
                    } else {
                        http_response_code(405);
                        echo json_encode(['error' => 'Método no permitido']);
                    }
                    break;
                case 'register':
                    if ($method === 'POST') {
                        $this->handleRegister();
                    } else {
                        http_response_code(405);
                        echo json_encode(['error' => 'Método no permitido']);
                    }
                    break;
                case 'animal':
                    $this->requireAuth();
                    if ($method === 'GET') {
                        if ($id) {
                            $this->handleAnimalesPorId($id);
                        } else {
                            $this->handleAnimalesAll();
                        }
                    } elseif ($method === 'POST') {
                        $this->handleCrearAnimal();
                    } elseif ($method === 'DELETE') {
                        if ($id) {
                            $this->handleDeleteAnimal($id);
                        } else {
                            http_response_code(400);
                            echo json_encode(['error' => 'ID requerido para DELETE']);
                        }
                    } else {
                        http_response_code(405);
                        echo json_encode(['error' => 'Método no permitido']);
                    }
                    break;
                case 'usuarios':
                    if ($method === 'GET') {
                        $this->handleUsuariosAll();
                    } else {
                        http_response_code(405);
                        echo json_encode(['error' => 'Método no permitido']);
                    }
                    break;
                default:
                    http_response_code(404);
                    echo json_encode(['error' => 'Recurso no encontrado']);
            }
        } catch (\Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
    }

    protected function handleLogin()
    {
        $input = json_decode(file_get_contents('php://input'), true);
        $email = $input['email'] ?? null;
        $password = $input['password'] ?? null;

        if (!$email || !$password) {
            http_response_code(400);
            echo json_encode(['error' => 'Email y password requeridos']);
            return;
        }

        $user = ApiUsuario::validarCredenciales($email, $password);

        if (!$user) {
            http_response_code(401);
            echo json_encode(['error' => 'Credenciales inválidas']);
            return;
        }

        $payload = [
            'sub' => $user['id'] ?? null,
            'email' => $user['email'] ?? $email
        ];

        $token = Jwt::generate($payload, 3600000); // 1 hora

        echo json_encode(['token' => $token]);
    }

    protected function handleRegister()
    {
        $input = json_decode(file_get_contents('php://input'), true);
        $email = $input['email'] ?? null;
        $password = $input['password'] ?? null;
        $nombre = $input['nombre'] ?? '';

        if (!$email || !$password) {
            http_response_code(400);
            echo json_encode(['error' => 'Email y password requeridos']);
            return;
        }

        $resultado = ApiUsuario::registrarUsuario($nombre, $email, $password);

        if ($resultado['success']) {
            http_response_code(201);
            echo json_encode([
                'message' => $resultado['message'],
                'id' => $resultado['id']
            ]);
        } else {
            http_response_code(400);
            echo json_encode(['error' => $resultado['message']]);
        }
    }

    /**
     * Valida la autenticación mediante JWT Token
     * 
     * Busca el token en los headers de la solicitud:
     * - Authorization: Bearer {token}
     * - O solo el token en el header Authorization
     * 
     * Si el token es válido, devuelve el payload del token
     * Si no hay token o es inválido, detiene la ejecución con error 401
     * 
     * @return array El payload del token validado
     */
    protected function requireAuth()
    {
        // Intentar obtener el header de diferentes fuentes
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? null;
        
        // Si no está en $_SERVER, intentar desde getallheaders()
        if (!$authHeader) {
            $headers = getallheaders();
            $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? null;
        }

        if (!$authHeader) {
            http_response_code(401);
            echo json_encode(['error' => 'Autorización requerida']);
            exit;
        }

        if (stripos($authHeader, 'Bearer ') === 0) {
            $token = trim(substr($authHeader, 7));
        } else {
            $token = $authHeader;
        }

        $payload = Jwt::validate($token);
        if (!$payload) {
            http_response_code(401);
            echo json_encode(['error' => 'Token inválido o expirado']);
            exit;
        }
        // Puedes exponer $payload si lo necesitas
        return $payload;
    }


    protected function handleAnimalesAll(){
        $animales = ApiAnimales::getAll();
        http_response_code(200);
        echo json_encode($animales);
    }

    protected function handleAnimalesPorId($id){
        $animales = ApiAnimales::getPorId($id);  

        if ($animales) {
            http_response_code(200);
            echo json_encode($animales);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Mascota no encontrada']);
        }        
    }

    protected function handleCrearAnimal(){
        $input = json_decode(file_get_contents('php://input'), true);
        
        $nombre = $input['nombre'] ?? null;
        $tipo = $input['tipo'] ?? null;
        $fecha_nacimiento = $input['fecha_nacimiento'] ?? null;
        $foto_url = $input['foto_url'] ?? null;
        $id_persona = $input['id_persona'] ?? null;

        if (!$nombre || !$tipo || !$fecha_nacimiento || !$foto_url || !$id_persona) {
            http_response_code(400);
            echo json_encode(['error' => 'Todos los campos son requeridos (nombre, tipo, fecha_nacimiento, foto_url, id_persona)']);
            return;
        }

        $resultado = ApiAnimales::crear($nombre, $tipo, $fecha_nacimiento, $foto_url, $id_persona);

        if ($resultado['success']) {
            http_response_code(201);
            echo json_encode($resultado);
        } else {
            http_response_code(400);
            echo json_encode(['error' => $resultado['message']]);
        }
    }

    protected function handleDeleteAnimal($id){
        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'ID requerido']);
            return;
        }

        $resultado = ApiAnimales::deletePorId($id);

        if ($resultado['success']) {
            http_response_code(200);
            echo json_encode($resultado);
        } else {
            http_response_code(400);
            echo json_encode(['error' => $resultado['message']]);
        }
    }

    protected function handleUsuariosAll(){
        $usuarios = ApiUsuario::getAll();
        http_response_code(200);
        echo json_encode($usuarios);
    }
}
