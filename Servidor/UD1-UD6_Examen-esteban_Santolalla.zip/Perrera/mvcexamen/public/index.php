<?php

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../app/iniciador.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Iniciar el núcleo de la app (router)
new \Cls\Mvc2app\Core();
