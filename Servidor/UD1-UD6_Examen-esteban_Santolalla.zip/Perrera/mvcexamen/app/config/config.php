<?php

//Configuración acceso a base de datos
define('DB_HOST', 'localhost'); //tu servidor de BD.
define('DB_USUARIO', '');
define('DB_PASSWORD', '');
define('DB_NOMBRE', ''); // Tu base de datos



//Ruta de la aplicación. /app o /src
define('RUTA_APP', (dirname(__DIR__)));

//Ruta url Ejemplo: http://localhost/ud5/mvc2app
//define ('RUTA_URL', '_URL_');
define ('RUTA_URL', 'http://localhost/Perrera/mvcexamen/public');
define ('BASE_URL', RUTA_URL . '/');

//define ('NOMBRESITIO', '_NOMBRE_SITIO');
define ('NOMBRESITIO', 'MVC con Composer Examen');

// Cargar archivo INI si es necesario.

// Otras configuraciones iniciales pueden ir aquí