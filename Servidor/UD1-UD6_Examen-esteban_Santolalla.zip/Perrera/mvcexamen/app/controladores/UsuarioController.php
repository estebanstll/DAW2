<?php


namespace Cls\Mvc2app;

use Cls\Mvc2app\Controlador;
use Cls\Mvc2app\Usuarios;

class UsuarioController extends Controlador{

    public function index():void{
        $this->vista("usuarios/index");
    }


    public function validarDatos():void{
        // Verificar que sea POST
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . BASE_URL . 'usuario');
            exit;
        }

        // Obtener datos del formulario
        $correo = $_POST['correo'] ?? null;
        $contraseña = $_POST['contraseña'] ?? null;

        // Validar que no estén vacíos
        if (empty($correo) || empty($contraseña)) {
            $_SESSION['error'] = 'Correo y contraseña son requeridos';
            header('Location: ' . BASE_URL . 'usuario');
            exit;
        }

        // Validar que solo Felix pueda hacer login
        if ($correo !== 'felix@veterinarios.com') {
            $_SESSION['error'] = 'No tienes permisos para acceder';
            header('Location: ' . BASE_URL . 'usuario');
            exit;
        }

        $respuesta = Usuarios::login($correo, $contraseña);

        if ($respuesta['status'] === 200 && isset($respuesta['data']['token'])) {

            $_SESSION['token'] = $respuesta['data']['token'];
            $_SESSION['correo'] = $correo;
            $_SESSION['permisos'] = true;
            
            // Redirigir a index o dashboard
            header('Location: ' . BASE_URL . 'AnimalesController/index');
            exit;
        } else {
            // Login fallido
            $error = $respuesta['data']['error'] ?? 'Error al iniciar sesión';
            $_SESSION['error'] = $error;
            header('Location: ' . BASE_URL . 'usuario');
            exit;
        }
    }


    public function register(){


        $this->vista("usuarios/register");

    }


    public function crearUsuario(){

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . BASE_URL . 'usuario/register');
            exit;
        }

        $nombre = $_POST['nombre'] ?? null;
        $correo = $_POST['correo'] ?? null;
        $contraseña = $_POST['contraseña'] ?? null;


        if (empty($nombre) || empty($correo) || empty($contraseña)) {
            $_SESSION['error'] = 'Nombre, correo y contraseña son requeridos';
            header('Location: ' . BASE_URL . 'usuario/register');
            exit;
        }

        $respuesta = Usuarios::register($nombre, $correo, $contraseña);

        if ($respuesta['status'] === 201 && isset($respuesta['data']['id'])) {
            // Registro exitoso
            $_SESSION['success'] = 'Usuario creado correctamente. Por favor, inicia sesión.';
            header('Location: ' . BASE_URL . 'usuario');
            exit;
        } else {
            // Registro fallido
            $error = $respuesta['data']['error'] ?? 'Error al crear el usuario';
            $_SESSION['error'] = $error;
            header('Location: ' . BASE_URL . 'usuario/register');
            exit;
        }
    }
}