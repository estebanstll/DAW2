<?php


namespace Cls\Mvc2app;

use Cls\Mvc2app\Controlador;
use Cls\Mvc2app\Animales;
use Cls\Mvc2app\Usuarios;

class AnimalesController extends Controlador{

public function index(){
    if(!$this->verificarPermisos()){
        header('Location: ' . BASE_URL . 'usuarioController');
        exit;
    }
    
    $respuesta = Animales::getAll();
    $this->vista("animales/index",["animales"=>$respuesta]);
}

public function verDetalles($id){

$respuesta = Animales::getPorId($id);
$this->vista("animales/detalles", ["animal"=>$respuesta]);
}


public function eliminar($id){
    Animales::deletePorId($id);
    $this->index();
}

public function crear(){
    if(!$this->verificarPermisos()){
        header('Location: ' . BASE_URL . 'usuarioController');
        exit;
    }
    
    $usuarios = Usuarios::getAll();
    $this->vista("animales/crear", ["usuarios" => $usuarios]);
}

public function guardarAnimal(){
    if($_SERVER['REQUEST_METHOD'] === 'POST'){
        $nombre = $_POST['nombre'] ?? null;
        $tipo = $_POST['tipo'] ?? null;
        $fecha_nacimiento = $_POST['fecha_nacimiento'] ?? null;
        $id_persona = $_POST['id_persona'] ?? null;
        $foto_url = $_POST['foto_url'] ?? null;

        if($nombre && $tipo && $fecha_nacimiento && $id_persona && $foto_url){
            $respuesta = Animales::crearAnimal($nombre, $tipo, $fecha_nacimiento, $id_persona, $foto_url);
            
            if($respuesta['status'] === 201 || $respuesta['status'] === 200){
                header("Location: " . BASE_URL . "animalesController");
                exit;
            } else {
                $this->vista("animales/crear", ["error" => "Error al crear el animal"]);
            }
        } else {
            $this->vista("animales/crear", ["error" => "Todos los campos son requeridos"]);
        }
    }
}

public function verificarPermisos(): bool{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    return isset($_SESSION['permisos']) && $_SESSION['permisos'] === true;
}

public function cerrarSesion(){
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    session_unset();
    session_destroy();
    
    header('Location: ' . BASE_URL . 'usuarioController');
    exit;
}



public function verDetallesAnimal($id){

$animal = Animales::getPorId( $id );
$this->vista("animales/detalles",["animales"=>$animal]);
}

}