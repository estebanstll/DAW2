<hr>
<H3>AQUI TU FOOTER</H3>

<script type="text/javascript" src="<?php echo RUTA_URL; ?>/js/main.js"></script>
</body>
</html>