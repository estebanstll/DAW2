<?php

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perrera</title>
</head>
<body>

    <?php
        $animalesData = [];
        $animalesStatus = null;

        if (is_array($animales)) {
            if (array_key_exists('data', $animales) && is_array($animales['data'])) {
                $animalesStatus = $animales['status'] ?? null;
                // Si es un solo animal (array asociativo), envolver en array
                if (isset($animales['data']['id']) || isset($animales['data']['nombre'])) {
                    $animalesData = [$animales['data']];
                } else {
                    $animalesData = $animales['data'];
                }
            } elseif (!empty($animales) && isset($animales[0]) && is_array($animales[0])) {
                $animalesData = $animales;
            }
        }
    ?>

    <?php if(empty($animalesData) || ($animalesStatus !== null && $animalesStatus !== 200)):?>
    <h1>No hay datos que mostrar</h1>

    <?php else: ?>
        <h1>Animales Disponibles</h1>
        <table border="1" cellpadding="10" cellspacing="0">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Tipo</th>
                    <th>Fecha de naciento</th>
                    <th>Foto</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($animalesData as $animal): ?>
                    <?php if (!is_array($animal)) { continue; } ?>
                    <tr>
                        <td><?= htmlspecialchars($animal['nombre'] ?? '') ?></td>
                        <td><?= htmlspecialchars($animal['tipo'] ?? '') ?></td>
                        <td><?= htmlspecialchars($animal['fecha_nacimiento'] ?? '') ?></td>
                        <td>
                            <?php if(!empty($animal['foto_url'] ?? null)): 
                                $fotoUrl = $animal['foto_url'];
                                if (strpos($fotoUrl, 'http') !== 0) {
                                    if (strpos($fotoUrl, '/public/') === 0) {
                                        $fotoUrl = '/Perrera/mvcexamen' . $fotoUrl;
                                    } else {
                                        $fotoUrl = '/Perrera/mvcexamen/public/img/' . basename($fotoUrl);
                                    }
                                }
                            ?>
                                <img src="<?= htmlspecialchars($fotoUrl) ?>" alt="Foto de <?= htmlspecialchars($animal['nombre']) ?>" style="max-width: 100px; max-height: 100px; object-fit: cover;" onerror="this.src='/Perrera/mvcexamen/public/img/placeholder.png'">
                            <?php else: ?>
                                <span>Sin foto</span>
                            <?php endif; ?>
                        </td>

                        <td>
                            
                            <a href="<?= BASE_URL ?>animalesController/eliminar/<?= htmlspecialchars($animal['id'] ?? '') ?>">
                                <button type="button">Eliminar Animal</button>
                            </a>

                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
       
        <a href="<?= BASE_URL ?>animalesController/cerrarSesion">
            <button type="button" style="background-color: #dc3545; margin-left: 10px;">Cerrar Sesión</button>
        </a>
        
    <?php endif; ?>