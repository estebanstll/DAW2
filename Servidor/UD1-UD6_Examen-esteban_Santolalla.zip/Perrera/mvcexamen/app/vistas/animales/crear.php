<?php

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Animal - Perrera</title>
</head>
<body>
    <div class="container">
        <h1>Crear Nuevo Animal</h1>
        
        <?php if(isset($error)): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <form method="POST" action="<?= BASE_URL ?>animalesController/guardarAnimal">
            <div class="form-group">
                <label for="nombre">Nombre del Animal:</label>
                <input type="text" id="nombre" name="nombre" required>
            </div>

            <div class="form-group">
                <label for="tipo">Tipo de Animal:</label>
                <input type="text" id="tipo" name="tipo" placeholder="Ej: Perro, Gato, Tortuga, Agaporní" required>
            </div>

            <div class="form-group">
                <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
                <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" required>
            </div>

            <div class="form-group">
                <label for="id_persona">Persona a Cargo:</label>
                <select id="id_persona" name="id_persona" required>
                    <option value="">Seleccione una persona</option>
                    <?php if(!empty($usuarios['data'])): ?>
                        <?php foreach($usuarios['data'] as $usuario): ?>
                            <option value="<?= htmlspecialchars($usuario['id']) ?>">
                                ID: <?= htmlspecialchars($usuario['id']) ?> - <?= htmlspecialchars($usuario['nombre']) ?>
                            </option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="foto_url">Ruta de la Imagen:</label>
                <input type="text" id="foto_url" name="foto_url" placeholder="Ej: /public/img/tortuga.jpeg" required>
                <div class="info">Introduce la ruta relativa de la imagen en el servidor</div>
            </div>

            <div class="button-group">
                <button type="submit">Guardar Animal</button>
                <a href="<?= BASE_URL ?>animalesController" style="text-decoration: none;">
                    <button type="button" class="btn-cancel">Cancelar</button>
                </a>
                <a href="<?= BASE_URL ?>animalesController/cerrarSesion" style="text-decoration: none;">
                    <button type="button" style="background-color: #dc3545;">Cerrar Sesión</button>
                </a>
            </div>
        </form>
    </div>
</body>
</html>
