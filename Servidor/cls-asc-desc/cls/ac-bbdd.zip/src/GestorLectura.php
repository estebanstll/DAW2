<?php

/**
 * Aquí implementa tus clases que definen tu negocio, en este caso la gestión de tus hobbyes.
 * 
 */

?>
