<?php

/**
 * Aquí tu script de visualización
 */

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Visualización de datos</title>
</head>
<body>
	<h1> Visualziación de datos de tu hobby</h1>
</body>
</html>