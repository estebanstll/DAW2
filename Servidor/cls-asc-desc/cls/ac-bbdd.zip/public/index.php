<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Archivo de entrada a la aplicación: formulario de login</title>
</head>
<body>
	<h1> Incluye aquí tu formulario de Login </h1>
	<p> Si el login es correcto redireciona al usuario a "principal.php", sino no le dejes pasar. </p>
</body>
</html>